# STAI-X Reproducibility Checklist

Complete this checklist for your accepted STAI-X paper.

## Fill In

Edit `staix-checklist.tex`. Replace all `[TODO]` and `[FILL: ...]` fields, then add one execution-elements table row for each main text figure or table result unit that requires running experiments, processing data, or producing released outputs. For now, do not include appendix or supplementary material results.

For each execution row, mark reproducibility as `Yes`, `Partial`, or `No`. `Yes` and `Partial` rows need an expected output; `No` rows do not and will not be included in the STAI-X reproducibility check. `Partial` and `No` rows need a reason in the notes.

If your code is on GitHub or another repository, include the URL and exact branch, tag, release, or commit.

Do not rename or remove the checklist questions, answer fields, justification fields, or execution-elements table columns.

Keep `staix_2026.sty` in the same folder when compiling.

## Compile

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error staix-checklist.tex
```

If `latexmk` is unavailable:

```bash
pdflatex staix-checklist.tex
pdflatex staix-checklist.tex
```

## Submit

Submit the completed `staix-checklist.tex` and the compiled `staix-checklist.pdf`.
